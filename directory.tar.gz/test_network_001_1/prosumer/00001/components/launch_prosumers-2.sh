python3 SmartHomeTraderWrapper.py 1 192.168.1.102 9000 > 1.out 2>&1 &
python3 SmartHomeTraderWrapper.py 2 192.168.1.102 9001 > 2.out 2>&1 &
python3 SmartHomeTraderWrapper.py 3 192.168.1.102 9002 > 3.out 2>&1 &

