explain the components
