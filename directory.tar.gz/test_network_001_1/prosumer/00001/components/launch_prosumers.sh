python3 SmartHomeTraderWrapper.py 1 192.168.1.102 9000 > 1.out 2>&1 &
python3 SmartHomeTraderWrapper.py 2 192.168.1.102 9001 > 2.out 2>&1 &
python3 SmartHomeTraderWrapper.py 3 192.168.1.102 9002 > 3.out 2>&1 &
python3 SmartHomeTraderWrapper.py 4 192.168.1.103 9003 > 4.out 2>&1 &
python3 SmartHomeTraderWrapper.py 5 192.168.1.103 9004 > 5.out 2>&1 &
python3 SmartHomeTraderWrapper.py 6 192.168.1.103 9005 > 6.out 2>&1 &
python3 SmartHomeTraderWrapper.py 7 192.168.1.104 9006 > 7.out 2>&1 &
python3 SmartHomeTraderWrapper.py 8 192.168.1.104 9007 > 8.out 2>&1 &
python3 SmartHomeTraderWrapper.py 9 192.168.1.106 9008 > 9.out 2>&1 &

