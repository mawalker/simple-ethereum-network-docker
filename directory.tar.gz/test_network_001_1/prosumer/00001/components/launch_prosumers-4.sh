python3 SmartHomeTraderWrapper.py 7 192.168.1.104 9006 > 7.out 2>&1 &
python3 SmartHomeTraderWrapper.py 8 192.168.1.104 9007 > 8.out 2>&1 &

