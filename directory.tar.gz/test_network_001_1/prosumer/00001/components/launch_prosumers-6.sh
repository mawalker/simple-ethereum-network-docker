python3 SmartHomeTraderWrapper.py 9 192.168.1.106 9008 > 9.out 2>&1 &

