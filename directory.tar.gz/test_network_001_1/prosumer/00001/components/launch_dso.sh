python3 DSOWrapper.py 192.168.1.111 9000 &
