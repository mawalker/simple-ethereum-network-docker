python3 SmartHomeTraderWrapper.py 4 192.168.1.103 9003 > 4.out 2>&1 &
python3 SmartHomeTraderWrapper.py 5 192.168.1.103 9004 > 5.out 2>&1 &
python3 SmartHomeTraderWrapper.py 6 192.168.1.103 9005 > 6.out 2>&1 &

